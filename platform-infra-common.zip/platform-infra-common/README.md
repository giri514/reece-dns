# reece-infra

Infrastructure code repo for the Reece eCommerce platform

## Instructions

1. Clone this repository repository:

   ```bash
   git clone https://github.com/dialexa/reece-infra.git
   ```

1. Change directories to the `reece-infra/environments/dev` and, if this is your first run, `init` Terraform:

   ```bash
   terraform init
   ```

1. Run the `plan` for Terraform and verify the changes that are output:

   ```bash
   terraform plan
   ```

1. Run the `apply` for Terraform:

   ```bash
   terraform apply
   ```

## Creating a new environment

1. Create the account in AWS
2. Define an S3 bucket, private, with the name defined in `main.tf`
3. Create a DynamoDB table with the name defined in `main.tf`. Create a parition key called `LockID`.
4. Set environment variables for the appropriate AWS credentials.
5. Run `terraform init`
6. Proceed with normal development/deployment flow.

